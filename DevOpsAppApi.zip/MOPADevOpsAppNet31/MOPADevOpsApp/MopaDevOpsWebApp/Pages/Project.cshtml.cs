using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.Net.Http.Headers;
using MopaDevOpsWebApp.ViewModels;

namespace MopaDevOpsWebApp.Pages
{
    public class ProjectModel : PageModel
    {
        private readonly ILogger<ProjectModel> _logger;
        private readonly IHttpClientFactory _factory;
        private readonly IConfiguration _configuration;

        public ProjectModel(ILogger<ProjectModel> logger, IHttpClientFactory factory, IConfiguration configuration)
        {
            _logger = logger;
            _factory = factory;
            _configuration = configuration;
        }

        public List<SelectListItem> Projects { get; set; }

        public async Task OnGet()
        {
            var httpRequestMessage = new HttpRequestMessage(HttpMethod.Get,"api/projects");
            var httpClient = _factory.CreateClient("DevOps");
            var httpResponseMessage = await httpClient.SendAsync(httpRequestMessage);

            if (httpResponseMessage.IsSuccessStatusCode)
            {
                using var contentStream =
                    await httpResponseMessage.Content.ReadAsStreamAsync();

                var lst = (await JsonSerializer.DeserializeAsync
                    <IEnumerable<Project>>(contentStream)).ToList<Project>();

                Projects = lst.Select(p => new SelectListItem { Value = p.id.ToString(), Text = p.name }).ToList();


            }




        }
    }
}
 
