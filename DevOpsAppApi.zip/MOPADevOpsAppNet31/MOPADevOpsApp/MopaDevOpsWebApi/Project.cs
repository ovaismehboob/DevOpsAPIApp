﻿using System;
using System.Collections.Generic;

#nullable disable

namespace MopaDevOpsWebApi
{
    public partial class Project
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Desc { get; set; }
    }
}
