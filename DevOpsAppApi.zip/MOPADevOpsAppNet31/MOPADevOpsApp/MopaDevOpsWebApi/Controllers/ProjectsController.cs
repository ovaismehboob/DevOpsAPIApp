﻿using Microsoft.AspNetCore.Mvc;
using MopaDevOpsWebApi.Infrastructure;
using System.Collections.Generic;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace MopaDevOpsWebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectsController : ControllerBase
    {

        private UnitOfWork<MopaDevOpsContext> _unitOfWork = new UnitOfWork<MopaDevOpsContext>();
        private Repository<Project> _repository;
        public ProjectsController()
        {
            //If you want to use Generic Repository with Unit of work
            _repository = new Repository<Project>(_unitOfWork);

        }
        
        // GET: api/<ProjectsController>
        [HttpGet]
        public IEnumerable<Project> Get()
        {
            return _repository.GetAll();
        }

        // GET api/<ProjectsController>/5
        [HttpGet("{id}")]
        public Project Get(int id)
        {
            return _repository.GetById(id);
        }

        // POST api/<ProjectsController>
        [HttpPost]
        public void Post([FromBody] Project value)
        {
            _repository.Insert(value);
            _unitOfWork.Save();
        }

        // PUT api/<ProjectsController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] Project value)
        {
            _repository.Update(value);
            _unitOfWork.Save();
        }

        // DELETE api/<ProjectsController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
            _repository.Delete(id);
            _unitOfWork.Save();
        }
    }
}
